import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Database {
    static public List<Applicant> applicantList = new ArrayList<>();
    static public List<Manager> managerList = new ArrayList<>();
    static public List<Officer> officerList = new ArrayList<>();
    static public List<Project> projectList = new ArrayList<>();
}