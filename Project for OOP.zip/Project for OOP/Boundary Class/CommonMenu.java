
interface CommonMenu{
    public void logout();
    public void displayMenu();
}

