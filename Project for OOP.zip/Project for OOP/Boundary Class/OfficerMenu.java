interface OfficerMenu extends CommonMenu{
    public void registerProjectAsOfficer();
    public void viewProjectsForApplyOfficer();
    public void checkRegistrationStatus();
    public void viewHandledProject();
    public void viewAndReplyEnquiryList();
    public void handleFlatBook();
    public void generateReceiptForFlatBooking();
}