
interface ApplicantMenu extends CommonMenu{
    
    public void viewAllAvailableProjects();
    public void applyForBTOProject();
    public void viewApplyFormStatus();
    public void viewTheAppliedProject();
    public void withdrawalApplyForm();
    public void submitEnquiry();
    public void displayEnquiries();
    public void editEnquiries();
    public void removeEnquiries();
}